﻿namespace B5B6_Fudbalski_klub_i_utakmice
{
    partial class Spisak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tbPozicija = new System.Windows.Forms.TextBox();
            this.btPrikazi = new System.Windows.Forms.Button();
            this.btIzadji = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Grad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pozicija";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(92, 30);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // tbPozicija
            // 
            this.tbPozicija.Location = new System.Drawing.Point(92, 57);
            this.tbPozicija.Name = "tbPozicija";
            this.tbPozicija.Size = new System.Drawing.Size(148, 20);
            this.tbPozicija.TabIndex = 3;
            // 
            // btPrikazi
            // 
            this.btPrikazi.Location = new System.Drawing.Point(57, 96);
            this.btPrikazi.Name = "btPrikazi";
            this.btPrikazi.Size = new System.Drawing.Size(75, 33);
            this.btPrikazi.TabIndex = 4;
            this.btPrikazi.Text = "Prikazi";
            this.btPrikazi.UseVisualStyleBackColor = true;
            // 
            // btIzadji
            // 
            this.btIzadji.Location = new System.Drawing.Point(149, 96);
            this.btIzadji.Name = "btIzadji";
            this.btIzadji.Size = new System.Drawing.Size(75, 33);
            this.btIzadji.TabIndex = 5;
            this.btIzadji.Text = "Izadji";
            this.btIzadji.UseVisualStyleBackColor = true;
            this.btIzadji.Click += new System.EventHandler(this.btIzadji_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 135);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(260, 121);
            this.listBox1.TabIndex = 6;
            // 
            // Spisak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btIzadji);
            this.Controls.Add(this.btPrikazi);
            this.Controls.Add(this.tbPozicija);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Spisak";
            this.Text = "Spisak";
            this.Load += new System.EventHandler(this.Spisak_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox tbPozicija;
        private System.Windows.Forms.Button btPrikazi;
        private System.Windows.Forms.Button btIzadji;
        private System.Windows.Forms.ListBox listBox1;
    }
}