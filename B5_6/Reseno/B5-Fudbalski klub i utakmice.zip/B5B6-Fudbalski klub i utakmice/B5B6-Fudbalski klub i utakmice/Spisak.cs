﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B5B6_Fudbalski_klub_i_utakmice
{
    public partial class Spisak : Form
    {
        SqlConnection baza = new SqlConnection(@"Data Source=DESKTOP-DN69ACH;Initial Catalog=B5_6;Integrated Security=True");

        public Spisak()
        {
            InitializeComponent();
        }

        private void Spisak_Load(object sender, EventArgs e)
        {
            SqlCommand select = new SqlCommand("select Grad from Grad", baza);
            baza.Open();
            using (SqlDataReader dr = select.ExecuteReader())
            {
                while (dr.Read())
                {
                    comboBox1.Items.Add(dr["Grad"].ToString());

                }
            }
            comboBox1.Sorted = true;
            baza.Close();
        }

        private void btIzadji_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
