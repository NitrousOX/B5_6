﻿namespace B5B6_Fudbalski_klub_i_utakmice
{
    partial class Gradovi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sifraTbx = new System.Windows.Forms.TextBox();
            this.gradTbx = new System.Windows.Forms.TextBox();
            this.pozivniBrojTbx = new System.Windows.Forms.TextBox();
            this.postanskiBrojTbx = new System.Windows.Forms.TextBox();
            this.BrojStanovnikaTbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btPrethodni = new System.Windows.Forms.Button();
            this.btSledeci = new System.Windows.Forms.Button();
            this.btNovi = new System.Windows.Forms.Button();
            this.btUpisi = new System.Windows.Forms.Button();
            this.btIzadji = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sifraTbx
            // 
            this.sifraTbx.Location = new System.Drawing.Point(139, 25);
            this.sifraTbx.Name = "sifraTbx";
            this.sifraTbx.Size = new System.Drawing.Size(82, 20);
            this.sifraTbx.TabIndex = 0;
            // 
            // gradTbx
            // 
            this.gradTbx.Location = new System.Drawing.Point(139, 51);
            this.gradTbx.Name = "gradTbx";
            this.gradTbx.Size = new System.Drawing.Size(133, 20);
            this.gradTbx.TabIndex = 1;
            // 
            // pozivniBrojTbx
            // 
            this.pozivniBrojTbx.Location = new System.Drawing.Point(139, 77);
            this.pozivniBrojTbx.Name = "pozivniBrojTbx";
            this.pozivniBrojTbx.Size = new System.Drawing.Size(54, 20);
            this.pozivniBrojTbx.TabIndex = 2;
            // 
            // postanskiBrojTbx
            // 
            this.postanskiBrojTbx.Location = new System.Drawing.Point(139, 103);
            this.postanskiBrojTbx.Name = "postanskiBrojTbx";
            this.postanskiBrojTbx.Size = new System.Drawing.Size(109, 20);
            this.postanskiBrojTbx.TabIndex = 3;
            // 
            // BrojStanovnikaTbx
            // 
            this.BrojStanovnikaTbx.Location = new System.Drawing.Point(139, 129);
            this.BrojStanovnikaTbx.Name = "BrojStanovnikaTbx";
            this.BrojStanovnikaTbx.Size = new System.Drawing.Size(109, 20);
            this.BrojStanovnikaTbx.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sifra";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Grad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Pozivni broj";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Postanski broj";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 132);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Broj stanovnika";
            // 
            // btPrethodni
            // 
            this.btPrethodni.Location = new System.Drawing.Point(13, 171);
            this.btPrethodni.Name = "btPrethodni";
            this.btPrethodni.Size = new System.Drawing.Size(75, 23);
            this.btPrethodni.TabIndex = 10;
            this.btPrethodni.Text = "Prethodni";
            this.btPrethodni.UseVisualStyleBackColor = true;
            // 
            // btSledeci
            // 
            this.btSledeci.Location = new System.Drawing.Point(94, 171);
            this.btSledeci.Name = "btSledeci";
            this.btSledeci.Size = new System.Drawing.Size(75, 23);
            this.btSledeci.TabIndex = 11;
            this.btSledeci.Text = "Sledeci";
            this.btSledeci.UseVisualStyleBackColor = true;
            // 
            // btNovi
            // 
            this.btNovi.Location = new System.Drawing.Point(175, 171);
            this.btNovi.Name = "btNovi";
            this.btNovi.Size = new System.Drawing.Size(75, 23);
            this.btNovi.TabIndex = 12;
            this.btNovi.Text = "Novi";
            this.btNovi.UseVisualStyleBackColor = true;
            this.btNovi.Click += new System.EventHandler(this.btNovi_Click);
            // 
            // btUpisi
            // 
            this.btUpisi.Location = new System.Drawing.Point(256, 171);
            this.btUpisi.Name = "btUpisi";
            this.btUpisi.Size = new System.Drawing.Size(75, 23);
            this.btUpisi.TabIndex = 13;
            this.btUpisi.Text = "Upisi";
            this.btUpisi.UseVisualStyleBackColor = true;
            this.btUpisi.Click += new System.EventHandler(this.btUpisi_Click);
            // 
            // btIzadji
            // 
            this.btIzadji.Location = new System.Drawing.Point(139, 200);
            this.btIzadji.Name = "btIzadji";
            this.btIzadji.Size = new System.Drawing.Size(75, 23);
            this.btIzadji.TabIndex = 14;
            this.btIzadji.Text = "Izadji";
            this.btIzadji.UseVisualStyleBackColor = true;
            this.btIzadji.Click += new System.EventHandler(this.btIzadji_Click);
            // 
            // Gradovi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 241);
            this.Controls.Add(this.btIzadji);
            this.Controls.Add(this.btUpisi);
            this.Controls.Add(this.btNovi);
            this.Controls.Add(this.btSledeci);
            this.Controls.Add(this.btPrethodni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BrojStanovnikaTbx);
            this.Controls.Add(this.postanskiBrojTbx);
            this.Controls.Add(this.pozivniBrojTbx);
            this.Controls.Add(this.gradTbx);
            this.Controls.Add(this.sifraTbx);
            this.Name = "Gradovi";
            this.Text = "Gradovi";
            this.Load += new System.EventHandler(this.Gradovi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox sifraTbx;
        private System.Windows.Forms.TextBox gradTbx;
        private System.Windows.Forms.TextBox pozivniBrojTbx;
        private System.Windows.Forms.TextBox postanskiBrojTbx;
        private System.Windows.Forms.TextBox BrojStanovnikaTbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btPrethodni;
        private System.Windows.Forms.Button btSledeci;
        private System.Windows.Forms.Button btNovi;
        private System.Windows.Forms.Button btUpisi;
        private System.Windows.Forms.Button btIzadji;
    }
}